## Explain Simple React Concepts like
##### useEffect
##### useState
##### Event Handler
##### When to declare a component
##### how much data to pass through props
