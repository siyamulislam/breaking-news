var shippingCost = [
    {
        price: 0,
        days: '8-10',
        type: 'Free',
        isSelected:false
    },
    {
        price: 3.99,
        days: '5-7',
        type: 'Regular',
        isSelected:false
    },
    {
        price: 7.99,
        days: '2-4',
        type: 'Standard',
        isSelected:false
    }
];

export default shippingCost;